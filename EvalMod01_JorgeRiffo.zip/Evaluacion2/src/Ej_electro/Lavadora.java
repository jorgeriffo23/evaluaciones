package Ej_electro;

public class Lavadora extends Electrodomesticos {

	private float carga;
	
	protected final static float cargapordef=5f;
	
	

	public Lavadora(int precio, float peso) {
		super(precio, peso);
		
	}



	public Lavadora(int precio, String color, char consumo_energetico, float peso,float carga) {
		super(precio, color, consumo_energetico, peso);
	    this.carga=carga;
		
	}



	public Lavadora(float carga) {
		
		carga=cargapordef;
	}



	public float getCarga() {
		return carga;
	}



	public void setCarga(float carga) {
		this.carga = carga;
	}
	
	public void preciofinal() {
		precioFinal();
		if(getCarga()>30) {
			setCarga(getPrecio()+40000);
		}
	}
	
	
	
}
