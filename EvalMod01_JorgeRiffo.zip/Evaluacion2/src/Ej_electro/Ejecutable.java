package Ej_electro;

public class Ejecutable {
	public static void main(String[] args) {

	Electrodomesticos elec[]=new Electrodomesticos[10];
	int j=1,k=1,s1=0,s2=0;
	
	
	
	elec[0]= new Lavadora(0, "gris", 'B', 50 ,30);
	elec[1]= new television(0, "azul",'C',20 , 45,true);
	elec[2]= new television(0,"negro",'B',30,50,false);
	elec[3]= new Lavadora(0, "blanco",'D', 80,40);
	elec[4]= new Lavadora(0, "negro", 'A', 40,20);
	elec[5]= new television(0, "azul",'C',20 , 45,true);
	elec[6]= new Lavadora(0, "negro", 'B', 60,35);
	elec[7]= new television(0, "azul",'C',20 , 45,true);
	elec[8]= new television(0, "azul",'C',20 , 45,true);
	elec[9]= new television(0, "azul",'C',20 , 45,true);
	
	

	System.out.println("-------------------------------------------");
	System.out.println("---------Lista de lavadoras----------------");
	for(int i=0;i<10;i++) {
		if(elec[i] instanceof Lavadora) {
			elec[i].precioFinal();
			System.out.println("Precio lavadora "+i+":"+elec[i].getPrecio());
			s1=s1+elec[i].getPrecio();
			
		}
		
	}
	System.out.println("-------------------------------------------");
	System.out.println("Suma total: $"+s1);
	System.out.println("-------------------------------------------");
	System.out.println("---------Lista de televisores--------------");
	for(int i=0;i<10;i++) {
		if(elec[i] instanceof television) {
			elec[i].precioFinal();
			System.out.println("Precio televisor "+i+":"+elec[i].getPrecio());
			s2=s2+elec[i].getPrecio();
		}
	}
	System.out.println("-------------------------------------------");
	System.out.println("Suma total: $"+s2);
	System.out.println("--------------------------------------------");
	System.out.println("---------Lista de electrodomesticos---------");
	for(int i=0;i<10;i++) {
		if(elec[i] instanceof Electrodomesticos) {
			System.out.println("Precio lavadora "+i+":"+elec[i].getPrecio());
			
		}
	}
	
	System.out.println("-------------------------------------------");
	System.out.println("-------------------------------------------");
	System.out.println("Suma total: $"+(s1+s2));
}
}