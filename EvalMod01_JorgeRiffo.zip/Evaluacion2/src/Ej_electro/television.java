package Ej_electro;

public class television extends Electrodomesticos{
	private float resolucion;
	private boolean sintonizador_TDT;
	
	protected final static float res_def=20; 
	protected final static boolean sint_def=false;
	
	
	public television(float resolucion,boolean sintonizador_TDT) {
		resolucion=res_def;
		sintonizador_TDT=sint_def;
	}
	
	
	
	public television(int precio, float peso) {
		super(precio, peso);
		
	}



	public television(int precio, String color, char consumo_energetico, float peso, float resolucion,
			boolean sintonizador_TDT) {
		super(precio, color, consumo_energetico, peso);
		this.resolucion = resolucion;
		this.sintonizador_TDT = sintonizador_TDT;
	}



	public float getResolucion() {
		return resolucion;
	}



	public void setResolucion(float resolucion) {
		this.resolucion = resolucion;
	}



	public boolean isSintonizador_TDT() {
		return sintonizador_TDT;
	}



	public void setSintonizador_TDT(boolean sintonizador_TDT) {
		this.sintonizador_TDT = sintonizador_TDT;
	}
	 
	public void precioFinal() {
		
		for (int i=0;i<6;i++) {
			if (getConsumo_energetico()==consumos[i]) {
				if(getPeso()<=19) {
					setPrecio(adconsumo[i]+8500+preciobasedef);
				}
				else if(getPeso()>19&&getPeso()<=49) {
					setPrecio(adconsumo[i]+40000+preciobasedef);
				}
				else if(getPeso()>49&&getPeso()<=79) {
					setPrecio(adconsumo[i]+70000+preciobasedef);
				}
				else if(getPeso()>79) {
					setPrecio(adconsumo[i]+85000+preciobasedef);
				}
			}
			
		}
		
		if(getResolucion()>40) {
			setPrecio((int)(getPrecio()*1.3));
		}
		if(isSintonizador_TDT()) {
			setPrecio(getPrecio()+45000);
		}
		
	}
	
	
	
	
	
}
