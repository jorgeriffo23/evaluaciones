package Ej_electro;

public class Electrodomesticos {

	private int precio;
	private String color;
	private char consumo_energetico;
	private float peso;
	
	protected final static int preciobasedef=100000;
	protected final static String colordef="blanco";
	protected final static char consumodef=  'f';
	protected final static float pesodef=5f;
	
	public char consumos[]= {'A','B','C','D','E','F'};
	public String colores[]= {"blanco","negro","rojo","azul","gris"};
	public int adconsumo[]= {85000,70000,50000,40000,25000,8500};
	
	
	public Electrodomesticos() {
		this(preciobasedef,colordef,consumodef,pesodef);
	}
	
	public Electrodomesticos(int precio, float peso) {
		
		this.precio = precio;
		this.peso = peso;
	}



	public Electrodomesticos(int precio, String color, char consumo_energetico, float peso) {
		
		this.precio = precio;
		this.color = color;
		this.consumo_energetico = consumo_energetico;
		this.peso = peso;
	}

	
	
	public int getPrecio() {
		return precio;
	}

	public void setPrecio(int precio) {
		this.precio = precio;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public char getConsumo_energetico() {
		return consumo_energetico;
	}

	public void setConsumo_energetico(char consumo_energetico) {
		this.consumo_energetico = consumo_energetico;
	}

	public float getPeso() {
		return peso;
	}

	public void setPeso(float peso) {
		this.peso = peso;
	}

	public void comprobarConsumoEnergetico(char letra) {
		for(int i=0;i<6;i++) {
		if (letra == consumos[i] ) {
			setConsumo_energetico(letra);
			i=6;
		}	
		else {
			setConsumo_energetico(consumodef);
		}
		}
	}
	
	public void comprobarColor(String color) {
		
		for(int i=0;i<5;i++) {
			if (color.equalsIgnoreCase(colores[i]) ) {
				setColor(color);
				i=5;
			}	
			else {
				setColor(colordef);
			}
			}
	}
	
	public void precioFinal() {
		
		for (int i=0;i<6;i++) {
		if (getConsumo_energetico()==consumos[i]) {
			if(getPeso()<=19) {
				setPrecio(adconsumo[i]+8500+preciobasedef);
			}
			else if(getPeso()>19&&getPeso()<=49) {
				setPrecio(adconsumo[i]+40000+preciobasedef);
			}
			else if(getPeso()>49&&getPeso()<=79) {
				setPrecio(adconsumo[i]+70000+preciobasedef);
			}
			else if(getPeso()>79) {
				setPrecio(adconsumo[i]+85000+preciobasedef);
			}
		}
		
	}
	
	}
	
	
}
